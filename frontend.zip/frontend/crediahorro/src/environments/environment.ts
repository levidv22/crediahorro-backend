export const environment = {
  production: false,
  apiUrl: 'https://gateway-production-7c45.up.railway.app'  // Tu gateway corre en el puerto 4040
};
