export const environment = {
  production: true,
  apiUrl: 'https://gateway-production-7c45.up.railway.app' // O puede ser tu dominio real si haces deploy externo
};
